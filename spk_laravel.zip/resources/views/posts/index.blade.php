@extends('layout')

@section('content')
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad adipisci amet commodi consectetur eaque est excepturi expedita, id illo impedit nulla, pariatur quam quos sapiente sequi, sit temporibus veritatis voluptas!
@endsection
@section('footer')

@endsection
