<?php $__env->startSection('content'); ?>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad adipisci amet commodi consectetur eaque est excepturi expedita, id illo impedit nulla, pariatur quam quos sapiente sequi, sit temporibus veritatis voluptas!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\spk_laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>